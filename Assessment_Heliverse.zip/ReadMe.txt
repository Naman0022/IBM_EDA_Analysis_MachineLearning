Dependencies:
Pandas-2.0.3
scikit-learn-1.3.2
scipy-1.10.1
matplotlib-3.7.5
seaborn-0.13.2

Keep Dataset in the same directory as name "IBM_HR.csv".
Set sampling Strategy according to models accuracy in SMOTE algorithm (taken = 0.90).
Set train/test splitting size(80%-20% size taken).